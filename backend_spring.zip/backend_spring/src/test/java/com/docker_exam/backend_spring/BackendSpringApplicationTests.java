package com.docker_exam.backend_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
